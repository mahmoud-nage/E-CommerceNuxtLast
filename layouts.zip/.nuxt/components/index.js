export { default as Footer } from '../..\\components\\Footer.vue'
export { default as HorizontalMenu } from '../..\\components\\horizontal-menu.js'
export { default as HorizontalNavbar } from '../..\\components\\Horizontal-navbar.vue'
export { default as Loading } from '../..\\components\\Loading.vue'
export { default as Logo } from '../..\\components\\Logo.vue'
export { default as Menu } from '../..\\components\\menu.js'
export { default as PageHeader } from '../..\\components\\Page-header.vue'
export { default as Portlet } from '../..\\components\\Portlet.vue'
export { default as Rightbar } from '../..\\components\\Rightbar.vue'
export { default as Sidebar } from '../..\\components\\Sidebar.vue'
export { default as Topbar } from '../..\\components\\Topbar.vue'
export { default as TwoColumnSidebar } from '../..\\components\\Two-column-sidebar.vue'
export { default as VuetifyLogo } from '../..\\components\\VuetifyLogo.vue'
export { default as AllNames } from '../..\\components\\forms\\allNames.vue'
export { default as BannerType } from '../..\\components\\forms\\bannerType.vue'
export { default as Categories } from '../..\\components\\forms\\categories.vue'
export { default as Desc } from '../..\\components\\forms\\desc.vue'
export { default as Discount } from '../..\\components\\forms\\discount.vue'
export { default as File } from '../..\\components\\forms\\file.vue'
export { default as Image } from '../..\\components\\forms\\image.vue'
export { default as Labels } from '../..\\components\\forms\\labels.vue'
export { default as Metas } from '../..\\components\\forms\\metas.vue'
export { default as Tax } from '../..\\components\\forms\\tax.vue'
export { default as Titles } from '../..\\components\\forms\\titles.vue'
export { default as Types } from '../..\\components\\forms\\types.vue'
export { default as Campaigns } from '../..\\components\\widgets\\Campaigns.vue'
export { default as Chat } from '../..\\components\\widgets\\Chat.vue'
export { default as CrmWidget } from '../..\\components\\widgets\\Crm-widget.vue'
export { default as Inbox } from '../..\\components\\widgets\\Inbox.vue'
export { default as MarketingReports } from '../..\\components\\widgets\\Marketing-reports.vue'
export { default as ProductsSales } from '../..\\components\\widgets\\Products-sales.vue'
export { default as Projections } from '../..\\components\\widgets\\Projections.vue'
export { default as RecentLeads } from '../..\\components\\widgets\\Recent-leads.vue'
export { default as RevenueHistory } from '../..\\components\\widgets\\Revenue-history.vue'
export { default as RevenueReport } from '../..\\components\\widgets\\Revenue-report.vue'
export { default as Revenue } from '../..\\components\\widgets\\Revenue.vue'
export { default as Todo } from '../..\\components\\widgets\\Todo.vue'
export { default as TopPerforming } from '../..\\components\\widgets\\Top-performing.vue'
export { default as WidgetChart } from '../..\\components\\widgets\\Widget-chart.vue'
export { default as Featured } from '../..\\components\\tables\\actions\\featured.vue'
export { default as Free } from '../..\\components\\tables\\actions\\free.vue'
export { default as IsAffilate } from '../..\\components\\tables\\actions\\is_affilate.vue'
export { default as IsBlocked } from '../..\\components\\tables\\actions\\is_blocked.vue'
export { default as IsPackage } from '../..\\components\\tables\\actions\\is_package.vue'
export { default as Published } from '../..\\components\\tables\\actions\\published.vue'

export const LazyFooter = import('../..\\components\\Footer.vue' /* webpackChunkName: "components_Footer" */).then(c => c.default || c)
export const LazyHorizontalMenu = import('../..\\components\\horizontal-menu.js' /* webpackChunkName: "components_horizontal-menu" */).then(c => c.default || c)
export const LazyHorizontalNavbar = import('../..\\components\\Horizontal-navbar.vue' /* webpackChunkName: "components_Horizontal-navbar" */).then(c => c.default || c)
export const LazyLoading = import('../..\\components\\Loading.vue' /* webpackChunkName: "components_Loading" */).then(c => c.default || c)
export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components_Logo" */).then(c => c.default || c)
export const LazyMenu = import('../..\\components\\menu.js' /* webpackChunkName: "components_menu" */).then(c => c.default || c)
export const LazyPageHeader = import('../..\\components\\Page-header.vue' /* webpackChunkName: "components_Page-header" */).then(c => c.default || c)
export const LazyPortlet = import('../..\\components\\Portlet.vue' /* webpackChunkName: "components_Portlet" */).then(c => c.default || c)
export const LazyRightbar = import('../..\\components\\Rightbar.vue' /* webpackChunkName: "components_Rightbar" */).then(c => c.default || c)
export const LazySidebar = import('../..\\components\\Sidebar.vue' /* webpackChunkName: "components_Sidebar" */).then(c => c.default || c)
export const LazyTopbar = import('../..\\components\\Topbar.vue' /* webpackChunkName: "components_Topbar" */).then(c => c.default || c)
export const LazyTwoColumnSidebar = import('../..\\components\\Two-column-sidebar.vue' /* webpackChunkName: "components_Two-column-sidebar" */).then(c => c.default || c)
export const LazyVuetifyLogo = import('../..\\components\\VuetifyLogo.vue' /* webpackChunkName: "components_VuetifyLogo" */).then(c => c.default || c)
export const LazyAllNames = import('../..\\components\\forms\\allNames.vue' /* webpackChunkName: "components_forms/allNames" */).then(c => c.default || c)
export const LazyBannerType = import('../..\\components\\forms\\bannerType.vue' /* webpackChunkName: "components_forms/bannerType" */).then(c => c.default || c)
export const LazyCategories = import('../..\\components\\forms\\categories.vue' /* webpackChunkName: "components_forms/categories" */).then(c => c.default || c)
export const LazyDesc = import('../..\\components\\forms\\desc.vue' /* webpackChunkName: "components_forms/desc" */).then(c => c.default || c)
export const LazyDiscount = import('../..\\components\\forms\\discount.vue' /* webpackChunkName: "components_forms/discount" */).then(c => c.default || c)
export const LazyFile = import('../..\\components\\forms\\file.vue' /* webpackChunkName: "components_forms/file" */).then(c => c.default || c)
export const LazyImage = import('../..\\components\\forms\\image.vue' /* webpackChunkName: "components_forms/image" */).then(c => c.default || c)
export const LazyLabels = import('../..\\components\\forms\\labels.vue' /* webpackChunkName: "components_forms/labels" */).then(c => c.default || c)
export const LazyMetas = import('../..\\components\\forms\\metas.vue' /* webpackChunkName: "components_forms/metas" */).then(c => c.default || c)
export const LazyTax = import('../..\\components\\forms\\tax.vue' /* webpackChunkName: "components_forms/tax" */).then(c => c.default || c)
export const LazyTitles = import('../..\\components\\forms\\titles.vue' /* webpackChunkName: "components_forms/titles" */).then(c => c.default || c)
export const LazyTypes = import('../..\\components\\forms\\types.vue' /* webpackChunkName: "components_forms/types" */).then(c => c.default || c)
export const LazyCampaigns = import('../..\\components\\widgets\\Campaigns.vue' /* webpackChunkName: "components_widgets/Campaigns" */).then(c => c.default || c)
export const LazyChat = import('../..\\components\\widgets\\Chat.vue' /* webpackChunkName: "components_widgets/Chat" */).then(c => c.default || c)
export const LazyCrmWidget = import('../..\\components\\widgets\\Crm-widget.vue' /* webpackChunkName: "components_widgets/Crm-widget" */).then(c => c.default || c)
export const LazyInbox = import('../..\\components\\widgets\\Inbox.vue' /* webpackChunkName: "components_widgets/Inbox" */).then(c => c.default || c)
export const LazyMarketingReports = import('../..\\components\\widgets\\Marketing-reports.vue' /* webpackChunkName: "components_widgets/Marketing-reports" */).then(c => c.default || c)
export const LazyProductsSales = import('../..\\components\\widgets\\Products-sales.vue' /* webpackChunkName: "components_widgets/Products-sales" */).then(c => c.default || c)
export const LazyProjections = import('../..\\components\\widgets\\Projections.vue' /* webpackChunkName: "components_widgets/Projections" */).then(c => c.default || c)
export const LazyRecentLeads = import('../..\\components\\widgets\\Recent-leads.vue' /* webpackChunkName: "components_widgets/Recent-leads" */).then(c => c.default || c)
export const LazyRevenueHistory = import('../..\\components\\widgets\\Revenue-history.vue' /* webpackChunkName: "components_widgets/Revenue-history" */).then(c => c.default || c)
export const LazyRevenueReport = import('../..\\components\\widgets\\Revenue-report.vue' /* webpackChunkName: "components_widgets/Revenue-report" */).then(c => c.default || c)
export const LazyRevenue = import('../..\\components\\widgets\\Revenue.vue' /* webpackChunkName: "components_widgets/Revenue" */).then(c => c.default || c)
export const LazyTodo = import('../..\\components\\widgets\\Todo.vue' /* webpackChunkName: "components_widgets/Todo" */).then(c => c.default || c)
export const LazyTopPerforming = import('../..\\components\\widgets\\Top-performing.vue' /* webpackChunkName: "components_widgets/Top-performing" */).then(c => c.default || c)
export const LazyWidgetChart = import('../..\\components\\widgets\\Widget-chart.vue' /* webpackChunkName: "components_widgets/Widget-chart" */).then(c => c.default || c)
export const LazyFeatured = import('../..\\components\\tables\\actions\\featured.vue' /* webpackChunkName: "components_tables/actions/featured" */).then(c => c.default || c)
export const LazyFree = import('../..\\components\\tables\\actions\\free.vue' /* webpackChunkName: "components_tables/actions/free" */).then(c => c.default || c)
export const LazyIsAffilate = import('../..\\components\\tables\\actions\\is_affilate.vue' /* webpackChunkName: "components_tables/actions/is_affilate" */).then(c => c.default || c)
export const LazyIsBlocked = import('../..\\components\\tables\\actions\\is_blocked.vue' /* webpackChunkName: "components_tables/actions/is_blocked" */).then(c => c.default || c)
export const LazyIsPackage = import('../..\\components\\tables\\actions\\is_package.vue' /* webpackChunkName: "components_tables/actions/is_package" */).then(c => c.default || c)
export const LazyPublished = import('../..\\components\\tables\\actions\\published.vue' /* webpackChunkName: "components_tables/actions/published" */).then(c => c.default || c)
