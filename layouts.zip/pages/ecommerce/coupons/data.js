const productData = [
  {
    id: 1,
    image: require("~/assets/images/products/product-1.png"),
    code: "NEW50",
    date: "09 Mar, 2020",
    startDate: "05 Mar, 2020",
    endDate: "01 Mar, 2020",
    amount: 32,
    amountType: 'EGP',
    status: "Active",
    type: "Card Base",
  },
];

export { productData };
