const productData = [
  {
    id: 1,
    image: require("~/assets/images/products/product-1.png"),
    name: "flash Deal",
    date: "09 Mar, 2020",
    startDate: "05 Mar, 2020",
    endDate: "01 Mar, 2020",
    countProduct: 32,
    status: "Active"
  }
];

export { productData };
