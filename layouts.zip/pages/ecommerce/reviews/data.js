const productData = [
  {
    id: 1,
    image: require("~/assets/images/products/product-1.png"),
    productName: "Blue color T-shirt",
    customer: "Blue color T-shirt",
    productOwner: "Blue color T-shirt",
    rating: "4.9",
    comment: "T-shirt",
    date: "09 Mar, 2020",
    status: "Active",
  }
];

export { productData };
