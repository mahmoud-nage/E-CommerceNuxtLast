import Vue from 'vue'
import VueStringFilter from 'vue-string-filter'

Vue.use(VueStringFilter)