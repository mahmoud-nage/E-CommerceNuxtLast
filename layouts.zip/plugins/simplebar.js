import Vue from 'vue'
import simplebar from "simplebar-vue";

Vue.component('simplebar', simplebar)
