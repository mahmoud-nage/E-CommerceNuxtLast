import Vue from 'vue'
import vco from "v-click-outside"

Vue.use(vco)
