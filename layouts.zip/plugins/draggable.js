import Vue from 'vue'

import VueDraggable from "vue-draggable";
Vue.use(VueDraggable);
