import Vue from 'vue'
import VueTour from 'vue-tour'

Vue.use(VueTour)