import Vue from 'vue'
import Lightbox from 'vue-easy-lightbox'
 
Vue.use(Lightbox)